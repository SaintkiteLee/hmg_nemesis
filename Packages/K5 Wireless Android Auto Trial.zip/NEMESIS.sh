#!/system/bin/sh
export PATH=/sbin:/vendor/bin:/system/sbin:/system/bin:/system/xbin
export LD_LIBRARY_PATH=/vendor/lib:/system/lib
case "$0" in /*) USB=${0%/*} ;; *) USB=$(pwd) ;; esac
STATE=/data/nemesis/k5-aa-apalign
PKG=k5.aa.apalign.guard
OUT=$USB/K5-AA-FIX/run-$(date +%Y%m%d-%H%M%S)-$$
mkdir -p "$OUT" || exit 1
exec > "$OUT/console.txt" 2>&1
echo "STARTED $(date)"
case "$(id 2>&1)" in uid=0\(*|uid=0\ *) ;; *) echo 'ABORT root required'; exit 1 ;; esac
[ "$(getprop ro.build.product2)" = 'DL3.KOR.S5W_M.V039.001.260902' ] || { echo 'ABORT wrong firmware'; exit 1; }
MD5=$(command -v md5 2>/dev/null)
[ -n "$MD5" ] || MD5=$(command -v md5sum 2>/dev/null)
[ -n "$MD5" ] || exit 1
file_md5(){ set -- $("$MD5" "$1" 2>/dev/null); echo "$1"; }
helper(){ CLASSPATH="$STATE/guard.jar" /system/bin/app_process /system/bin com.saintkite.k5aa.Main "$@"; }
phase(){ cat "$STATE/phase" 2>/dev/null; }
export_result(){
    for name in phase baseline.txt events.txt radio-log.txt network-snapshots.txt network-checkpoints.txt ap-auth-events.txt phone-observation.txt; do [ -f "$STATE/$name" ] && cp "$STATE/$name" "$OUT/$name"; done
    helper status "$STATE" > "$OUT/status.txt" 2>&1 || { echo STATUS_FAILED > "$OUT/result.txt"; sync; return 1; }
    [ -f /data/nemesis/logs/k5.aa.apalign.guard/monitor.log ] && cp /data/nemesis/logs/k5.aa.apalign.guard/monitor.log "$OUT/guard-console.txt"
    case "$(phase)" in
      committed|rolled_back)
        # Final-only cleanup: keep the compatibility app on success, remove it on rollback.
        if [ "$(phase)" = rolled_back ]; then
            helper verify-restored "$STATE" > "$OUT/restore-verification.txt" 2>&1 || { echo RESTORE_UNCONFIRMED > "$OUT/result.txt"; sync; return 1; }
            if [ -d "/data/nemesis/apps/$PKG" ]; then
                /system/xbin/nemesis uninstall "$PKG" > "$OUT/guard-cleanup.txt" 2>&1 || { echo GUARD_CLEANUP_FAILED > "$OUT/result.txt"; sync; return 1; }
            fi
            [ ! -d "/data/nemesis/apps/$PKG" ] || { echo GUARD_STILL_PRESENT > "$OUT/result.txt"; sync; return 1; }
            echo GUARD_ABSENT_VERIFIED >> "$OUT/guard-cleanup.txt"
        else
            echo 'Deferred until this USB is removed: clear a new stale USB-AA state if idle, then remove guard.' > "$OUT/guard-cleanup.txt"
            echo ready > "$STATE/export-complete"
        fi
        echo "FINAL_$(phase)" > "$OUT/result.txt"
        sync; mv "$USB/NEMESIS.data" "$USB/NEMESIS.data.used" 2>/dev/null; sync; return 0 ;;
      *) echo 'RESTORE_PENDING_OR_FAILED: leave backups intact and inspect logs' > "$OUT/result.txt"; sync; return 1 ;;
    esac
}
current=$(phase)
case "$current" in
  committed|rolled_back) export_result; exit $? ;;
  testing)
    am start -n com.daudio.app.deviceconnections/.k5fix.TrialResultActivity > "$OUT/result-screen.txt" 2>&1
    count=0
    while [ "$count" -lt 540 ]; do
      case "$(phase)" in committed|rolled_back) export_result; exit $? ;; esac
      sleep 1; count=$((count + 1))
    done
    export_result; exit $? ;;
  armed|applying|restoring)
    echo 'RECOVER_PENDING' >> "$OUT/console.txt"
    echo rollback > "$STATE/decision"
    /system/xbin/nemesis service stop "$PKG/monitor" 2>/dev/null
    helper restore "$STATE" > "$OUT/recovery.txt" 2>&1
    export_result; exit $? ;;
  '') ;;
  *) echo 'ABORT unknown transaction state'; exit 1 ;;
esac
# Preserve previous trial backups and refuse concurrent recovery workers.
for old in /data/nemesis/k5-aa-fix /data/nemesis/k5-aa-session-fix /data/nemesis/k5-aa-network-diag /data/nemesis/k5-aa-auth-diag /data/nemesis/k5-aa-authwait-diag /data/nemesis/k5-aa-apcompare; do
    case "$(cat "$old/phase" 2>/dev/null)" in
      armed|applying|testing|restoring) echo 'ABORT an earlier AA trial still needs recovery'; exit 1 ;;
    esac
done
# Match the exact framework and app that were analyzed before changing anything.
[ "$(file_md5 /system/framework/framework.odex)" = 'eab5af504694910d946f9067310b744a' ] || { echo 'ABORT framework differs'; exit 1; }
[ "$(file_md5 /system/framework/services.odex)" = '6ce1dd85f9c873dfa037f75b72807cc4' ] || { echo 'ABORT Wi-Fi service differs'; exit 1; }
[ "$(file_md5 /system/app/PhoneProjection.odex)" = 'c19f5f1b49b207a1df7142aaa572877c' ] || { echo 'ABORT PhoneProjection differs'; exit 1; }
[ "$(file_md5 /system/app/HKMC_GPM.odex)" = 'def8588772f648a6acedbed8ecdcd5d8' ] || { echo 'ABORT AA service differs'; exit 1; }
[ "$(file_md5 "$USB/aa/guard.jar")" = '31a84eb6dc577733612ff468cef980c3' ] || { echo 'ABORT helper hash mismatch'; exit 1; }
[ "$(file_md5 "$USB/aa/k5.aa.apalign.guard.zip")" = 'e31fe9972439ef2f246297b844a6e2f0' ] || { echo 'ABORT guard package hash mismatch'; exit 1; }
# Finish the previous export interrupted by early USB removal. Never overwrite its backup.
PREVIOUS=/data/nemesis/k5-aa-apcompare
PREVIOUS_PKG=k5.aa.apcompare.guard
if [ "$(cat "$PREVIOUS/phase" 2>/dev/null)" = rolled_back ]; then
    CLASSPATH="$USB/aa/guard.jar" /system/bin/app_process /system/bin com.saintkite.k5aa.Main verify-restored "$PREVIOUS" > "$OUT/previous-restore-verification.txt" 2>&1 || { echo 'ABORT previous restoration differs; no new trial'; sync; exit 1; }
    if [ -d "/data/nemesis/apps/$PREVIOUS_PKG" ]; then
        /system/xbin/nemesis uninstall "$PREVIOUS_PKG" > "$OUT/previous-guard-cleanup.txt" 2>&1 || exit 1
    fi
    [ ! -d "/data/nemesis/apps/$PREVIOUS_PKG" ] || { echo 'ABORT previous guard still present'; exit 1; }
    echo PREVIOUS_GUARD_ABSENT_VERIFIED >> "$OUT/previous-guard-cleanup.txt"
fi
if [ -f "$STATE/original.properties" ]; then
    # A power loss between writing the backup and arming must not overwrite it.
    helper restore "$STATE" > "$OUT/recovery.txt" 2>&1; export_result; exit $?
fi
mkdir -p "$STATE" || exit 1
chmod 700 "$STATE" || exit 1
cp "$USB/aa/guard.jar" "$STATE/guard.jar" || exit 1
[ "$(file_md5 "$STATE/guard.jar")" = '31a84eb6dc577733612ff468cef980c3' ] || exit 1
MEDIA_ID=$(cat "$USB/aa/trial-media-id" 2>/dev/null)
[ -n "$MEDIA_ID" ] || { echo 'ABORT missing USB identity'; exit 1; }
helper snapshot "$STATE" '2cf54d5fda8c45be2e8f906345fa359bd2fdfa8a8219c1032f106f192847139f' "$USB" "$MEDIA_ID" > "$OUT/snapshot.txt" 2>&1 || { echo 'SNAPSHOT_FAILED: no AP or settings changes'; exit 1; }
/system/xbin/nemesis install "$USB/aa/k5.aa.apalign.guard.zip" > "$OUT/install-guard.txt" 2>&1
install_rc=$?
if [ "$install_rc" != 0 ]; then
    echo rollback > "$STATE/decision"
    /system/xbin/nemesis service stop "$PKG/monitor" 2>/dev/null
    helper restore "$STATE" > "$OUT/install-failure-restore.txt" 2>&1
    export_result; exit 1
fi
# The registered guard starts before it installs the bridge or changes AP state.
count=0
while [ "$count" -lt 120 ]; do
    case "$(phase)" in
      testing)
        am start -n com.daudio.app.deviceconnections/.k5fix.ApInfoActivity > "$OUT/ap-info-screen.txt" 2>&1
        echo 'AP_READY_REMOVE_USB_TEST_AA_THEN_REINSERT' > "$OUT/result.txt"
        sync
        exit 0 ;;
      committed) export_result; exit $? ;;
      rolled_back) export_result; exit 1 ;;
    esac
    sleep 1; count=$((count + 1))
done
echo 'GUARD_NOT_READY: requesting rollback' > "$OUT/result.txt"
echo rollback > "$STATE/decision"
sync
export_result
exit 1
